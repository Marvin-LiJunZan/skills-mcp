"""Persist the Fuyao alias token for hithink-finance consumers."""

from __future__ import annotations

import os
import sys
from pathlib import Path


_ENV_NAME = "HITHINK_FINANCE_API_KEY"


def credentials_path() -> Path:
    """Return the platform-specific hithink-finance credentials file."""
    if sys.platform == "win32":
        appdata = os.environ.get("APPDATA")
        if not appdata:
            raise OSError("APPDATA is not set")
        config_dir = Path(appdata)
    elif sys.platform == "darwin":
        config_dir = Path.home() / "Library" / "Application Support"
    else:
        xdg_config_home = os.environ.get("XDG_CONFIG_HOME")
        config_dir = (
            Path(xdg_config_home).expanduser()
            if xdg_config_home
            else Path.home() / ".config"
        )
    return config_dir / "hithink-finance" / "credentials.env"


def save_api_key(alias_token: str) -> Path:
    """Atomically store an alias token using hithink-finance's env-file format."""
    if not isinstance(alias_token, str) or not alias_token or "\n" in alias_token or "\r" in alias_token:
        raise ValueError("aliasToken must be a non-empty single-line string")

    target = credentials_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(target.suffix + ".tmp")
    temporary.write_text(f"{_ENV_NAME}={alias_token}\n", encoding="utf-8")
    os.chmod(temporary, 0o600)
    os.replace(temporary, target)
    return target
